# Using pandas makes it easy to read table files in CSV/TSV format.
# import pandas as pd means importing the pandas library and giving it the alias pd.
import pandas as pd

# encoding = 'utf-8': Character encoding
with open('Contact_angle_database.csv', 'r', encoding='utf-8') as data:
    polymer_data = [line.split(',') for line in data.readlines()]  # Use comma as the delimiter when reading
    data = pd.DataFrame(data = polymer_data)  # Convert a list to a DataFrame
    data.replace('\n', '', regex=True, inplace=True)  # Remove spaces in the DataFrame
    data.replace('﻿', '', regex=True, inplace=True)  # Remove spaces in a DataFrame
    data.columns = data.iloc[0]  # Set the first row as column names in a DataFrame
    data.drop([0], inplace=True)  # Delete the first row as it is currently being used as a column name.

from sklearn.preprocessing import MinMaxScaler
import numpy as np

feature_number = 18
# data.iloc[:, 1:] selects all rows and all columns starting from the second column.
# In other words, it retrieves all columns except the first one.
# Most programming languages use zero-based indexing, so index 1 refers to the second column.
data_features = data.iloc[:, :feature_number]
data_features = np.array(data_features)
data_features = data_features.astype(np.float32)

# data.iloc[:, 0:1] selects the contact angle column.
data_target = data.iloc[:, feature_number]
data_target = np.array(data_target)
data_target = data_target.astype(np.float32)
data_target = data_target.reshape(len(data_target), 1)

train_num = 45
train_data_features = data_features[:train_num, :]
train_data_target = data_target[:train_num, :]

test_data_features = data_features[train_num:, :]
test_data_target = data_target[train_num:, :]

import torch
from torch import nn
from torch.nn import functional as F


# Define our own model class by inheriting from torch.nn.Module.
# This allows us to easily use various machine learning functionalities implemented in PyTorch.

class NNModel(nn.Module):

    # The class constructor method, which is automatically called when running NNModel(13).
    # self refers to the instance itself, and num_features is the parameter we pass in.
    # For example, when we run model = NNModel(13), 13 is num_features, and self refers to the model instance.
    def __init__(self, num_features):
        # The following line calls the constructor of the parent class (nn.Module).
        super(NNModel, self).__init__()
        node = 500
        # Define multiple fully connected layers
        self.l1 = nn.Linear(num_features, node)
        self.l2 = nn.Linear(node, node)
        self.l3 = nn.Linear(node, node)
        self.l4 = nn.Linear(node, 1)

    # After we instantiate a model with model = NNModel(13),
    # we can get predictions by calling pred = model(features).
    # Calling model(features) will execute the forward method defined below.
    def forward(self, features):
        x = self.l1(features)
        x = F.elu(x)
        x = self.l4(x)
        return x


model_name = 'model13'
loss_func_name = 'MSELoss'
potimizer_name = 'RMSprop'
lr = 0.0001
model = NNModel(feature_number)
loss_func = nn.MSELoss()
optimizer = torch.optim.RMSprop(model.parameters(),lr=lr)

from torch.utils.data import Dataset, DataLoader


# Define a custom class that inherits from torch.utils.data.Dataset
class BostonDataset(Dataset):

    # This is the constructor method, which takes data_features and data_target as inputs.
    def __init__(self, data_features, data_target):
        self.data_features = data_features
        self.data_target = data_target
        # The following line is necessary; it calls the constructor of the parent class.
        super(BostonDataset, self).__init__()

    # Must define the following method: takes an index as input and returns the features and target corresponding to that index.
    def __getitem__(self, index):
        return torch.tensor(self.data_features[index], dtype=torch.float), torch.tensor(self.data_target[index],
                                                                                        dtype=torch.float)

    # Must define the following method to return the number of data samples.
    def __len__(self):
        return len(self.data_features)

# Instantiate the train and validation datasets separately
train_dataset = BostonDataset(train_data_features, train_data_target)
validation_dataset = BostonDataset(test_data_features, test_data_target)

# Separate dataloaders for train and validation are defined. The usage of the dataloaders can be seen in the training and testing sections below.
# Note that batch_size is defined here. Batch_size refers to the number of data points processed for training simultaneously.
train_data_loader = DataLoader(train_dataset, batch_size=20)
test_data_loader = DataLoader(validation_dataset, batch_size=20)

epoch_num = 10000

# Define the function used for training
def train():
    model.train()
    sum_loss = 0
    # The code below uses train_data_loader, and in each iteration of the loop it retrieves batch_size data samples
    for batch_features, batch_real_contact_angle in train_data_loader:
        batch_pred_contact_angle = model(batch_features)
        loss = loss_func(batch_pred_contact_angle, batch_real_contact_angle)
        sum_loss += loss.item() * len(batch_features)
        optimizer.zero_grad()  # Zero out the gradients of the optimizer
        loss.backward()  # Backpropagation: compute the gradients d loss / d x
        optimizer.step()  # Update all parameters
    return sum_loss / len(train_dataset)


# Define the function used for testing
def test():
    model.eval()
    sum_loss = 0
    for batch_features, batch_real_contact_angle in test_data_loader:
        batch_pred_contact_angle = model(batch_features)
        loss = loss_func(batch_pred_contact_angle, batch_real_contact_angle)
        sum_loss += loss.item() * len(batch_features)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    return sum_loss / len(validation_dataset)


from tqdm import tqdm

train_loss_list = []
test_loss_list = []

# Method for displaying a progress bar
with tqdm(total=epoch_num) as pbar:
    for e in range(epoch_num):
        train_loss = train()
        test_loss = test()
        train_loss_list.append(train_loss)
        test_loss_list.append(test_loss)

        # Advance the progress bar by one step
        pbar.update(1)
        # Set the suffix of the progress bar
        pbar.set_postfix_str(f"Train RMSE: {train_loss**0.5}, Validation RMES: {test_loss**0.5}")

# Plot the changes in training/testing RMSE below
from matplotlib import pyplot as plt

plt.plot(range(epoch_num), train_loss_list, label="train")
plt.plot(range(epoch_num), test_loss_list, label="validation")
plt.legend()
plt.xlabel("Epoch")
plt.ylabel("RMSE")

fig_name = model_name + '-' + loss_func_name + '-' + potimizer_name + '-' + 'lr=' + str(
    lr) + '-' + 'epoch_num = ' + str(epoch_num) + '.jpg'
plt.savefig(fig_name)

# Obtain predicted contact angles using the features from the test dataset
pred_contact_angle = model(torch.tensor(test_data_features, dtype=torch.float))
# Since the predicted data is a two-dimensional matrix and not suitable for subsequent operations,
# use the reshape method here to convert the 2D matrix into a 1D vector
pred_contact_angle = pred_contact_angle.reshape(len(pred_contact_angle))
# Convert data from torch.Tensor type to numpy.ndarray type
pred_contact_angle = pred_contact_angle.detach().numpy()
# Since the true contact angle data is a two-dimensional matrix and not suitable for subsequent operations,
# use the reshape method here to convert the 2D matrix into a 1D vector
real_contact_angle = test_data_target.reshape(len(test_data_target))


# Plot the changes in training/validation RMSE below
from matplotlib import pyplot as plt
start_num = 4000

plt.figure(figsize=(6, 6))
plt.scatter(pred_contact_angle, test_data_target.reshape(len(test_data_target)))
plt.plot([0, 120], [0, 120])
plt.xlabel("Real")
plt.ylabel("Pred")
fig_name = model_name + '-' + loss_func_name +  '-' + potimizer_name +  '-' + 'lr=' + str(lr) +  '-' +  'epoch_num = ' + str(epoch_num) + 'test_set.jpg'
plt.savefig(fig_name)
from sklearn import metrics
mse = metrics.mean_squared_error(real_contact_angle, pred_contact_angle)
rmse = np.sqrt(mse)
r2 = metrics.r2_score(real_contact_angle, pred_contact_angle)


from sklearn.preprocessing import MinMaxScaler
import numpy as np
data_features = data.iloc[:, :feature_number]
data_features = np.array(data_features)
data_features = data_features.astype(np.float32)

# Obtain predicted contact angles using the features from the test dataset
pred_contact_angle = model(torch.tensor(data_features, dtype=torch.float))
# Since the predicted data is a two-dimensional matrix and not suitable for subsequent operations,
# use the reshape method here to convert the 2D matrix into a 1D vector
pred_contact_angle = pred_contact_angle.reshape(len(pred_contact_angle))
# Convert data from torch.Tensor type to numpy.ndarray type
pred_contact_angle = pred_contact_angle.detach().numpy()

with open('train_loss.txt', 'a') as f:
    for x,y in zip(range(epoch_num-start_num), train_loss_list[start_num:]):
        f.write(str(x))
        f.write(' ')
        f.write(str(y))
        f.write('\n')

with open('test_loss.txt', 'a') as f:
    for x,y in zip(range(epoch_num-start_num), test_loss_list[start_num:]):
        f.write(str(x))
        f.write(' ')
        f.write(str(y))
        f.write('\n')

with open('test_data_pred.txt', 'a') as f:
    txt = pred_contact_angle.astype(np.str_)
    for x in txt:
        f.write(x)
        f.write(' \n')

with open('test_data_real.txt', 'a') as f:
    txt = real_contact_angle.astype(np.str_)
    for x in txt:
        f.write(x)
        f.write(' \n')


pred_contact_angle = model(torch.tensor(train_data_features, dtype=torch.float))
pred_contact_angle = pred_contact_angle.reshape(len(train_data_features))
pred_contact_angle = pred_contact_angle.detach().numpy()
real_contact_angle = train_data_target.reshape(len(train_data_target))

with open('train_data_pred.txt', 'a') as f:
    txt = pred_contact_angle.astype(np.str_)
    for x in txt:
        f.write(x)
        f.write(' \n')

with open('train_data_real.txt', 'a') as f:
    txt = real_contact_angle.astype(np.str_)
    for x in txt:
        f.write(x)
        f.write(' \n')


#Chitosan prediction
pred_contact_angle = model(torch.tensor([41.1,0.227272727,0,0.045454545,0.227272727,0,0.090909091,0,0.090909091,0,0,0,0,0,0,0,0,0.045454545], dtype=torch.float))
pred_contact_angle = pred_contact_angle.reshape(len(pred_contact_angle))
pred_contact_angle = pred_contact_angle.detach().numpy()
print("CS", pred_contact_angle)
#PAN prediction
pred_contact_angle = model(torch.tensor([50	,0.428571429	,0,	0.142857143	,0.142857143	,0	,0	,0	,0,	0,	0	,0,	0,	0.142857143	,0	,0	,0,	0], dtype=torch.float))
pred_contact_angle = pred_contact_angle.reshape(len(pred_contact_angle))
pred_contact_angle = pred_contact_angle.detach().numpy()
print("PAN", pred_contact_angle)
#PVB prediction
pred_contact_angle = model(torch.tensor([45.2	,0.583333333	,0.0416666666666667,	0.166666666666667	,0.125	,0	,0	,0	,0,	0,	0	,0,	0.0833333333333333,	0	,0	,0	,0,	0], dtype=torch.float))
pred_contact_angle = pred_contact_angle.reshape(len(pred_contact_angle))
pred_contact_angle = pred_contact_angle.detach().numpy()
print("PVB", pred_contact_angle)
#PVP prediction
pred_contact_angle = model(torch.tensor([51.1	,0.529411765	,0	,0.235294118	,0.058823529,	0	,0	,0.058823529	,0	,0	,0	,0	,0	,0.058823529	,0	,0	,0	,0.058823529], dtype=torch.float))
pred_contact_angle = pred_contact_angle.reshape(len(pred_contact_angle))
pred_contact_angle = pred_contact_angle.detach().numpy()
print("PVP", pred_contact_angle)
#HEC prediction
pred_contact_angle = model(torch.tensor([63.2,	0.476190476,	0	,0.097560976	,0.119047619,	0	,0.071428571,	0	,0.107142857,0,	0	,0	,0	,0,	0,	0	,0,	0], dtype=torch.float))
pred_contact_angle = pred_contact_angle.detach().numpred_contact_angle = pred_contact_angle.reshape(len(pred_contact_angle))
pred_contact_angle = pred_contact_angle.detach().numpy()
print("HEC", pred_contact_angle)
#PEO prediction
pred_contact_angle = model(torch.tensor([64.3,	0.571428571	,0	,0.285714286	,0	,0,	0	,0	,0.142857143,	0,	0	,0	,0,	0	,0,	0,	0	,0], dtype=torch.float))
pred_contact_angle = pred_contact_angle.reshape(len(pred_contact_angle))
pred_contact_angle = pred_contact_angle.detach().numpy()
print("PEO", pred_contact_angle)
#CA prediction
pred_contact_angle = model(torch.tensor([43,0.419354839,	0.064516129,	0.048387097,0.161290323,	0,	0.032258065,	0,	0.064516129,	0,	0,	0,	0.064516129,	0	,0	,0	,0,	0], dtype=torch.float))
pred_contact_angle = pred_contact_angle.reshape(len(pred_contact_angle))
pred_contact_angle = pred_contact_angle.detach().numpy()
print("CA", pred_contact_angle)
#EC prediction
pred_contact_angle = model(torch.tensor([13.8,0.564102564	,0.076923077	,0.102564103,	0.128205128	,0	,0	,0,	0.076923077,	0	,0	,0	,0,	0,	0	,0,	0,	0], dtype=torch.float))
pred_contact_angle = pred_contact_angle.reshape(len(pred_contact_angle))
pred_contact_angle = pred_contact_angle.detach().numpy()
print("EC", pred_contact_angle)





















